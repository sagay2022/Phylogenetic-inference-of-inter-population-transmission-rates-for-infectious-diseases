sir_1 <- function(beta, gamma, S0, I0, R0, times) {
  require(deSolve) # for the "ode" function
  
# the differential equations:
  sir_equations <- function(time, variables, parameters) {
    with(as.list(c(variables, parameters)), {
      dS <- -beta * I * S
      dI <-  beta * I * S - gamma * I
      dR <-  gamma * I
      return(list(c(dS, dI, dR)))
    })
  }
  
# the parameters values:
  parameters_values <- c(beta  = beta, gamma = gamma)

# the initial values of variables:
  initial_values <- c(S = S0, I = I0, R = R0)
  
# solving
  out <- ode(initial_values, times, sir_equations, parameters_values)

# returning the output:
  as.data.frame(out)
}

sir_2 <- function(alpha1, beta1, gamma1, alpha2, beta2, gamma2, S11_0, S12_0, I11_0, I12_0, R11_0, R12_0, S22_0, S21_0, I22_0, I21_0, R22_0, R21_0, times) {

  require(deSolve) # for the "ode" function
  
  sir_equations <- function(time, variables, parameters) {
    with(as.list(c(variables, parameters)), {
      	dS11 <- -beta1 * (I11+I12) * S11 - alpha1 * S11
	dS12 <- -beta1 * (I11+I12) * S12 + alpha2 * S22
      	dI11 <-  beta1 * (I11+I12) * S11 - gamma1 * I11
	dI12 <-  beta1 * (I11+I12) * S12 - gamma1 * I12	
      	dR11 <-  gamma1 * I11
	dR12 <-  gamma1 * I12

	dS22 <- -beta2 * (I22+I21) * S22 - alpha2 * S22
	dS21 <- -beta2 * (I22+I21) * S21 + alpha1 * S11
      	dI22 <-  beta2 * (I22+I21) * S22 - gamma2 * I22
	dI21 <-  beta2 * (I22+I21) * S21 - gamma2 * I21	
      	dR22 <-  gamma2 * I22
	dR21 <-  gamma2 * I21
      	return(list(c(dS11, dS12, dI11, dI12, dR11, dR12, dS22, dS21, dI22, dI21, dR22, dR21)))
    })
  }
  
# the parameters values:
  parameters_values <- c(alpha1 = alpha1, beta1  = beta1, gamma1 = gamma1, alpha2 = alpha2, beta2 = beta2, gamma2 = gamma2)

# the initial values of variables:
  initial_values <- c(S11 = S11_0, S12 = S12_0, I11 = I11_0, I12 = I12_0, R11 = R11_0, R12 = R12_0, S22 = S22_0, S21 = S21_0, I22 = I22_0, I21 = I21_0, R22 = R22_0, R21 = R21_0)
  
# solving
  out <- ode(initial_values, times, sir_equations, parameters_values)

# returning the output:
  as.data.frame(out)
}


transNet = function (inputSIR, total1, total2, travelprob_w, infection_v){
	net = matrix(0,total1,4)
	net[1,1] = 1
	net[1,2] = 1
	for(i in 2:dim(inputSIR)[1]){
		#debug
		if((sum(net[,1] > 0 & net[,3] == 0 & net[,4] == 0) != inputSIR$I11[i-1]) || (sum(net[,3] > 0 & net[,4] == 0) != inputSIR$R11[i-1])){
			print("the numbers do not add up")
			print(i)
			print(c(sum(net[,1] > 0 & net[,3] == 0 & net[,4] == 0),inputSIR$I11[i-1]))
			print(c(sum(net[,3] > 0 & net[,4] == 0),inputSIR$R11[i-1]))
			return (1)
		}
		
		#find the infected (not recovered and not migrate) at current time
		ancestors = which(net[,1] > 0 & net[,3] == 0 & net[,4] == 0)
		
		#find the susceptible at current time
		susceptible = which(net[,1] == 0 & net[,4] == 0)
		
		#find the new infection, recovery, and migration
		ninf = inputSIR$S11[i-1]-inputSIR$S11[i]
		nrec = inputSIR$R11[i]-inputSIR$R11[i-1]
		#nmig = (inputSIR$S21[i]+inputSIR$I21[i]+inputSIR$R21[i])-(inputSIR$S21[i-1]+inputSIR$I21[i-1]+inputSIR$R21[i-1])
		nmig = 0
	
		#find the new migration
		if(nmig > 0){
			index = sample(susceptible,nmig)
			net[index,4] = 2
			
			#update susceptible
			susceptible = susceptible[-match(index,susceptible)]
		}
		
		#find the new infected
		if(ninf > 0 && length(susceptible)>0){
			if(length(susceptible) == 1){
				x = susceptible
				#add infection time
				net[x,1] = i
				#add ancestor
				for(j in 1:length(x)){
					if(length(ancestors) == 1){
						net[x[j],2] = ancestors
					}else{
						net[x[j],2] = sample(ancestors,1)
					}
				}
			}else{
				x = sample(susceptible,ninf)
				#add infection time
				net[x,1] = i
				#add ancestor
				for(j in 1:length(x)){
					if(length(ancestors) == 1){
						net[x[j],2] = ancestors
					}else{
						net[x[j],2] = sample(ancestors,1)
					}
				}
			}
		}
		
		#add recovery time
		if(nrec > 0){
			if(length(ancestors) == 1){
					net[ancestors,3] = i
			}else{
				net[sample(ancestors,nrec),3] = i
			}
		}
	}
	ndays = i-1
	index = which(net[,1]>0)
	numinfection = length(index)
	net[net[,3]==0,3] = ndays+1
	
	#generate between-population transmissions
	new = matrix(0, 1, 4)
	for(j in 1:ndays){
		ntraveler = rbinom(1,total2,travelprob_w)
		I_t1 = inputSIR[j,2]
		x_t2 = rbinom(1, ntraveler*total1, infection_v*I_t1/total1)
		if(x_t2 > 0){
			newnet = matrix(0, x_t2, 4)
			newnet[,1] = j
			newnet[,2] = sample(which(net[,1]<=3 & net[,3]>3 & net[,1] != 0), x_t2, replace=T)
			new = rbind(new, newnet)
		}
	}
	new = new[-1,]
	new[,4] = 1
	estimate = dim(new)[1]/total2/sum(inputSIR[1:ndays,2])	
	
	result = list(net=as.matrix,ndays=as.numeric,estimate=as.numeric, truerate=as.numeric)
	result$net = rbind(net,new)
	result$ndays = ndays
	result$estimate = estimate
	result$truerate = infection_v*travelprob_w
	
	return (result)
}

sir_pop = function(beta, gamma, total, times){
  npopulation = length(beta)
  result = list()
  for(j in 1:npopulation){
    SIRresult = sir_1(beta=beta[j], gamma = gamma[j], S0 = total[j]-1, I0 = 1, R0 = 0, times = seq(0, times))
    SIRresult = round(SIRresult[,-1])
    SIRresult$I = SIRresult$I+total[j]-apply(SIRresult,1,sum)
    for(i in 2:dim(SIRresult)[1]){
      if(SIRresult$S[i]>SIRresult$S[i-1]){
        SIRresult$I[i] = SIRresult$I[i] + (SIRresult$S[i] - SIRresult$S[i-1])
        SIRresult$S[i] = SIRresult$S[i-1]
      }
      if(SIRresult$R[i]<SIRresult$R[i-1]){
        SIRresult$I[i] = SIRresult$I[i] - (SIRresult$R[i-1] - SIRresult$R[i])
        SIRresult$R[i] = SIRresult$R[i-1]
      }
    }
    result[[j]] = SIRresult
  }
  result
}

findAncestors = function(nodenumber,transnet){
	anc = ancestor = nodenumber
	while(ancestor != 1){
		ancestor = transnet[ancestor,2]
		anc = c(anc, ancestor)
	}
	anc
}

substituteDescendantNodes = function(ancnodes, tree, ind_time, time_internode){
	if(is.vector(ancnodes)){
		numnodes = 1
		num_individual = length(ancnodes)
		root_node = ancnodes
		root_time = time_internode
	}else{
		numnodes = dim(ancnodes)[2]
		num_individual = dim(ancnodes)[1]
		root_node = ancnodes[,numnodes]
		root_time = time_internode[numnodes]
	}
	
	if(numnodes == 1){
		all = which(ancnodes==1)
		input = paste("(",paste(all,collapse=",",sep=","),")",sep="")
		output = paste(all,ind_time[all]-root_time,sep=":")	
		#treestr = str_replace(tree, input, paste(output,collapse=","))
		if(length(output)==2){
			y = paste(output,collapse=",")
		}else{
			y = output[1]
			for(i in 2:(length(output)-1)){
				y = paste("(",y,",",output[i],"):0",sep="")
			}
			y = paste(y,",",output[length(output)],sep="")
		}
		treestr = str_replace(tree, input, y)
		return (treestr)
	}else if(numnodes==2){
		sons=cbind(rep(0, num_individual), ancnodes[,1])
	}else{
		nodes = ancnodes[,-numnodes]
		sons = rep(0, dim(nodes)[1])
		while(length(dim(nodes)) > 0){
			diff_nodes = 0
			sons = cbind(sons, nodes[,dim(nodes)[2]]) 
			start = dim(nodes)[2]
			
			for(i in 1:(start-1)){
				if(length(which(nodes[,start] - nodes[,i] == -1)) > 0){
					diff_nodes = c(diff_nodes, i)
				}
			}
			
			if(length(diff_nodes)==1){
				break
			}else if(length(diff_nodes)==2){
				nodes = nodes[,diff_nodes[-1]]
				sons = cbind(sons, nodes)
			}else{
				nodes = nodes[,diff_nodes[-1]]
			}
		}
	}
	
	if(dim(sons)[2]==2){
		sons=sons[,-1]
		x=paste("(",paste(which(sons == 1),collapse=",",sep=","),"):", abs(time_internode[1]-root_time),sep="")
		all = which(ancnodes[,numnodes]==1)
		input = paste("(",paste(all,collapse=",",sep=","),")",sep="")
		w = sons
		w[which(w>0)] = 1
		individual = which((ancnodes[,numnodes]-w)==1)
		individual = paste(individual,ind_time[individual]-root_time,sep=":")
		output = c(x,individual)
		#treestr = gsub(input, paste(output,collapse=","), tree)
		if(length(output)==2){
			y = paste(output,collapse=",")
		}else{
			y = output[1]
			for(i in 2:(length(output)-1)){
				y = paste("(",y,",",output[i],"):0",sep="")
			}
			y = paste(y,",",output[length(output)],sep="")
		}
		treestr = str_replace(tree, input, y)
	}else{
		sons=sons[,-1]
		numsons = dim(sons)[2]
		x=rep("",numsons)
		time = rep(0,numsons)
		for(i in 1:numsons){
			for(j in 1:numnodes){
				if(sum(abs(sons[,i]-ancnodes[,j]))==0){
					time[i]=abs(time_internode[j]-root_time)
					break
				}
			}
			x[i] = paste("(",paste(which(sons[,i] == 1),collapse=",",sep=","),"):",time[i],sep="")
		}
		all = which(root_node==1)
		input = paste("(",paste(all,collapse=",",sep=","),")",sep="")
		w = apply(sons,1,sum)
		w[which(w>0)] = 1
		individual = which((root_node-w)==1)
		individual = paste(individual,ind_time[individual]-root_time,sep=":")
		output = c(x,individual)		
		#treestr = str_replace(tree, input, paste(output,collapse=","))
		if(length(output)==2){
			y = paste(output,collapse=",")
		}else{
			y = output[1]
			for(i in 2:(length(output)-1)){
				y = paste("(",y,",",output[i],"):0",sep="")
			}
			y = paste(y,",",output[length(output)],sep="")
		}
		treestr = str_replace(tree, input, y)
	}

	return (treestr)
}

ancTree = function(transnet, sample_inf, murate){
	#infected = which(transnet[,1] > 1)
	#sample_inf = sample(infected, samplesize)
	samplesize = length(sample_inf)
	total = dim(transnet)[1]
	ancestry = matrix(0,length(sample_inf),total)
	for(i in 1:length(sample_inf)){
		ancestry[i, findAncestors(sample_inf[i], transnet)[-1]] = 1
	}
	
	num_offspring = apply(ancestry,2,sum)
	ancnode_index = which(num_offspring>1)
	anc_nodes = ancestry[,ancnode_index]
	w = apply(anc_nodes,2,sum)
	anc_nodes = anc_nodes[,order(w)]
	ancnode_index = ancnode_index[order(w)]
	index = 0
	for(i in 1:(length(ancnode_index)-1)){
		if(sum(index==i)>0){
				next
		}
		for(j in (i+1):length(ancnode_index)){
			if(sum(abs(anc_nodes[,j]-anc_nodes[,i])) == 0){
				index = c(index,j)
			}
		}
	}
	if(length(index) > 1){
		index = index[-1]
		anc_nodes = anc_nodes[,-index]
		ancnode_index = ancnode_index[-index]
	}
	
	anc_time = transnet[ancnode_index,1]*murate
	ind_time = transnet[sample_inf,1]*murate
	numnodes=dim(anc_nodes)[2]
	
	tree = paste("(",paste(1:samplesize,collapse=","),");",sep="")

	for(i in numnodes:2){
		index = 0
		time_internode = anc_time[i]
		for(j in 1:(i-1)){
			if(length(which(anc_nodes[,i] - anc_nodes[,j] == -1)) == 0){
					index=c(index,j)
					time_internode = c(anc_time[j], time_internode)
			}
		}
		index=c(index[-1],i)
		tree = substituteDescendantNodes(anc_nodes[,index], tree, ind_time, time_internode)
	}
	tree = substituteDescendantNodes(anc_nodes[,1], tree, ind_time, time_internode)
	tree = read.tree(text=tree)
	names = paste("S",sample_inf,"_",transnet[sample_inf,4],sep="")
	tree$tip.label = names[as.numeric(tree$tip.label)]
	tree = write.tree(tree)
	#tree = tree.node2name(tree, names)
	return (tree)
}

findMajorClades <- function(inode, nodematrix, taxaname, root, clades){
        x = write.subtree(inode,nodematrix,taxaname,root=root)
        y = species.name(x)
        prop = length(grep(spname[1],y))/length(y)
        if((inode != root) && (prop > 0.8 || prop < 0.2)){
                clades = c(x,clades)
                return (clades)
        }else{
                right = nodematrix[inode,2]
                left = nodematrix[inode,3]
                clades = findMajorClades(right, nodematrix, taxaname, root, clades=clades)
                clades = findMajorClades(left, nodematrix, taxaname, root, clades=clades)
                #print(clades)
        }
}

transNet_pop = function (inputSIR, popindex, total, travelprob_w, infection_v){
  npopulation = length(total)
	net = matrix(0,total[popindex],4)
	net[1,1] = 1
	net[1,2] = 1
	for(i in 2:dim(inputSIR)[1]){
		#debug
		if((sum(net[,1] > 0 & net[,3] == 0 & net[,4] == 0) != inputSIR$I[i-1]) || (sum(net[,3] > 0 & net[,4] == 0) != inputSIR$R[i-1])){
			print("the numbers do not add up")
			print(i)
			print(c(sum(net[,1] > 0 & net[,3] == 0 & net[,4] == 0),inputSIR$I[i-1]))
			print(c(sum(net[,3] > 0 & net[,4] == 0),inputSIR$R[i-1]))
			return (1)
		}
		
		#find the infected (not recovered and not migrate) at current time
		ancestors = which(net[,1] > 0 & net[,3] == 0 & net[,4] == 0)
		
		#find the susceptible at current time
		susceptible = which(net[,1] == 0 & net[,4] == 0)
		
		#find the new infection, recovery, and migration
		ninf = inputSIR$S[i-1]-inputSIR$S[i]
		nrec = inputSIR$R[i]-inputSIR$R[i-1]
	
		#find the new infected
		if(ninf > 0 && length(susceptible)>0){
			if(length(susceptible) == 1){
				x = susceptible
				#add infection time
				net[x,1] = i
				#add ancestor
				for(j in 1:length(x)){
					if(length(ancestors) == 1){
						net[x[j],2] = ancestors
					}else{
						net[x[j],2] = sample(ancestors,1)
					}
				}
			}else{
				x = sample(susceptible,ninf)
				#add infection time
				net[x,1] = i
				#add ancestor
				for(j in 1:length(x)){
					if(length(ancestors) == 1){
						net[x[j],2] = ancestors
					}else{
						net[x[j],2] = sample(ancestors,1)
					}
				}
			}
		}
		
		#add recovery time
		if(nrec > 0){
			if(length(ancestors) == 1){
					net[ancestors,3] = i
			}else{
				net[sample(ancestors,nrec),3] = i
			}
		}
	}
	ndays = i-1
	index = which(net[,1]>0)
	numinfection = length(index)
	net[net[,3]==0,3] = ndays+1
	net[,4] = popindex
	
	#generate between-population transmissions
	estimate = rep(NA,npopulation)
	for(i in 1:npopulation){
	  if(i == popindex){
	    next
	  }
  	new = matrix(0, 1, 4)
  	for(j in 1:ndays){
  		ntraveler = rbinom(1,total[i],travelprob_w[i])
  		I_t1 = inputSIR[j,2]
  		x_t2 = rbinom(1, ntraveler*total[popindex], infection_v*I_t1/total[popindex])
  		if(x_t2 > 0){
  			newnet = matrix(0, x_t2, 4)
  			newnet[,1] = j
  			newnet[,2] = sample(which(net[,1]<=3 & net[,3]>3 & net[,1] != 0), x_t2, replace=T)
  			new = rbind(new, newnet)
  		}
  	}
  	new[,4] = i
  	new = new[-1,]
  	estimate[i] = dim(new)[1]/total[i]/sum(inputSIR[1:ndays,2])
  	net = rbind(net,new)
	}
	row.names(net) = paste("S",1:dim(net)[1],"_",net[,4],sep="")
	
	result = list(net=as.matrix,ndays=as.numeric,estimate=as.vector, truerate=as.vector)
	result$net = net
	result$ndays = ndays
	result$estimate = estimate
	result$truerate = infection_v*travelprob_w
	result$truerate[popindex] = NA
	
	return (result)
}

buildTree = function(SIRresult, total, samplesize, travelprob_w, infection_v, murate){
  npopulation = length(total)
  transnet = list()
  sampleindex = list()
  num_infection = matrix(0,npopulation,npopulation)
  truerate = matrix(0,npopulation,npopulation)
  rate_est = matrix(0,npopulation,npopulation)
  rate_est_sample = matrix(0,npopulation,npopulation)
  
  generatetree = 1
  while(generatetree==1){
    #num_infection[i,j] is the number of transmissions from population j to population i
    for(i in 1:npopulation){
      x = transNet_pop(SIRresult[[i]], popindex=i, total=total, travelprob_w = travelprob_w, infection_v=infection_v)
      transnet[[i]] = x$net
      truerate[i,] = x$truerate
      rate_est[i,] = x$estimate
      for(j in 1:npopulation){
        num_infection[i,j] = sum(transnet[[i]][,4]==j & transnet[[i]][,1]>0)
      }
    }
    
    #num_sample[i,j] is the numbers of transmissions from sample j to sample i
    num_sample = num_infection
    for(i in 1:npopulation){
      num_sample[,i] = rmultinom(1, size=samplesize[i], prob=num_infection[,i]/sum(num_infection[,i]))
    }

    for(i in 1:npopulation){
      sampleindex[[i]] = 0
      for(j in 1:npopulation){
        index_infection = which(transnet[[i]][,4]==j & transnet[[i]][,1]>0)
        sampleindex[[i]] = c(sampleindex[[i]],sample(index_infection, num_sample[i,j]))
      }
      sampleindex[[i]] = sampleindex[[i]][-1]
    }
    
    for(i in 1:npopulation){
      for(j in 1:npopulation){
        if(j==i){
          rate_est_sample[i,j] = NA
        }else{
          X = num_sample[i,j]
          I1 = num_infection[i,i]
          I1_sample = num_sample[i,i]
          I2 = num_infection[j,j]
          n2 = samplesize[j]
          N2 = total[j]
          y = sampleindex[[i]]
          index = which(transnet[[i]][y,4] == i)
          t = sum(transnet[[i]][y[index],3]-transnet[[i]][y[index],1])
          print(c(X,I1,I1_sample,I2,n2,N2,t))
          rate_est_sample[i,j] = I2*X/(n2-X)/(N2*I1*t/I1_sample)
        }
      }
    }
    
    tree = ancTree(transnet[[1]], sample_inf=sampleindex[[1]], murate=murate)
    for(i in 2:npopulation){
      x = ancTree(transnet[[i]], sample_inf=sampleindex[[i]], murate=murate)
      tree = paste("(",tree,",",x,"):0.1",sep="")
    }
    finaltree = paste("(",str_replace_all(tree,";",":0.1"),",","outgroup:0.1",");",sep="")
    tree_1 = read.tree(text=finaltree)
    if(sum(table(tree_1$tip.label)>1)==0 & length(tree_1[[4]])-1 == tree_1[[3]]){
      print("tree is good!")
      generatetree=0
    }
  }
  
  result = list(net=as.list, tree=as.character, num_infection=as.matrix, truerate=as.matrix, rate_est_all=as.matrix, rate_est_sample=as.matrix)
  result$net = transnet
  result$tree = finaltree
  result$num_infection = num_infection
  result$truerate = truerate
  result$rate_est_all = rate_est
  result$rate_est_sample = rate_est_sample
  result
}

rateSampleEstimation = function(transtree, spname){
  transnet = transtree$net
  finaltree = transtree$tree
  num_infection = transtree$num_infection
  tree = read.tree.nodes(finaltree)
  taxanames = tree$names
  nodematrix = tree$nodes
  root = dim(nodematrix)[1]
  npopulation = length(spname)
  samplesize = total = rep(0,npopulation)
  
  for(i in 1:npopulation){
    samplesize[i] = length(grep(spname[i],taxanames))
    total[i] = sum(transnet[[i]][,4]==i)
  }

  #find major clades
  clades = findMajorClades_pop(inode=root, nodematrix, spname=spname, taxaname=taxanames, root=root, threshold=0.6, clades="")
  clades = clades[clades!=""]
  num_clades = length(clades)
  
  #find num_sample
  subsample_taxanames = list()
  num_sample = matrix(0,npopulation,npopulation)
  pop_clade_index = rep(0,npopulation)
  for(i in 1:num_clades){
    subsample_taxanames[[i]] = species.name(clades[i])
    x = rep(0,npopulation)
    for(j in 1:npopulation){
        x[j] = length(grep(spname[j],subsample_taxanames[[i]]))
    }
    popindex = which(x==max(x))
    if(sum(x)>sum(num_sample[popindex,])){
      num_sample[popindex,]=x
      pop_clade_index[popindex] = i
    }
  }
  
  rate_est_sample = matrix(0,npopulation,npopulation)
  for(i in 1:npopulation){
    if(sum(num_sample[i,])<10){
      next
    }
    
    #find the sum removal time in the major population
    x = subsample_taxanames[[pop_clade_index[[i]]]]
    major_names = x[grep(spname[i],x)]
    x = row.names(transnet[[i]])
    index = match(major_names,x)
    t = sum(transnet[[i]][index,3]-transnet[[i]][index,1])
    
    for(j in 1:npopulation){
      if(j==i){
        rate_est_sample[i,j] = NA
      }else{
        X = num_sample[i,j]
        I1 = num_infection[i,i]
        I1_sample = num_sample[i,i]
        I2 = num_infection[j,j]
        n2 = samplesize[j]
        N2 = total[j]
        rate_est_sample[i,j] = I2*X/(n2-X)/(N2*I1*t/I1_sample)
      }
    }
  }
  
  result = list(clades=as.vector,pop_clade_index=as.vector,rate_est=as.matrix)
  result$clades = clades
  result$pop_clade_index = pop_clade_index
  result$rate_est = rate_est_sample
  result
}		

findMajorClades_pop <- function(inode, nodematrix, spname, taxaname, root, threshold, clades){
  x = write.subtree(inode,nodematrix, taxaname,root=root)
  y = species.name(x)
  if(length(y)<10){
    return (clades)
  }
  
  num_sample = rep(0,length(spname))
  for(i in 1:length(spname)){
    num_sample[i] = length(grep(spname[i],y))
  }
  
  if(sum(num_sample)==0){
    prop = 0
  }else{
    prop = max(num_sample/sum(num_sample))
  }

  if((inode != root) && (prop > threshold)){
          clades = c(x,clades)
          return (clades)
  }else{
          right = nodematrix[inode,2]
          left = nodematrix[inode,3]
          clades = findMajorClades_pop(right, nodematrix, spname, taxaname, root, threshold, clades=clades)
          clades = findMajorClades_pop(left, nodematrix, spname, taxaname, root, threshold, clades=clades)
          #print(clades)
  }
}


