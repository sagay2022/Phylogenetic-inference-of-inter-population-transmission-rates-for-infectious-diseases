#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
n1 = as.numeric(args[1])
n2 = as.numeric(args[2])
n3 = as.numeric(args[3])
n4 = as.numeric(args[4])

source("/home/lliu/tranrate/simulation/tranLibrary.R")
source("/Users/lliu/Library/CloudStorage/OneDrive-UniversityofGeorgia/Dropbox/Research/transmission rate estimation/simulation/rcode/tranLibrary.R")
library(phybase)
library(stringr)
rate = c(0.002,0.004, 0.006, 0.008)
nsample = c(100,200,300,400,500)
mutationrate = c(0.0001,0.001,0.01)

n1=n2=n3=n4=1
tranrate = rate[n1]
numsample = nsample[n2]
murate = mutationrate[n3]

print(tranrate)
print(numsample)
print(murate)
#######################################
# simulate from SIR
#######################################
npop = 2
total=rep(1000000,npop)
beta=rep(0.0000005,npop)
gamma=rep(0.05,npop)
time=50
SIRresult = sir_pop(beta=beta, gamma=gamma, total=total, times=time)

#######################################
# generate transmission tree
#######################################
travelprob_w = rep(0.000001,npop)
infection_v = tranrate
samplesize = rep(numsample,npop)
result = buildTree(SIRresult, total, samplesize, travelprob_w, infection_v, murate)

########################################
# simulate sequences and estimate tree
########################################
treefile = paste("tree_",n1,"_",n2,"_",n3,"_",n4,sep="")
seqfile = paste("seq_",n1,"_",n2,"_",n3,"_",n4,sep="")
outfile = paste("outfile_",n1,"_",n2,"_",n3,"_",n4,sep="")
ratefile = paste("rate_",n1,"_",n2,"_",n3,"_",n4,".RData", sep="")

write(result$tree,treefile)
system(paste("seq-gen -or -mHKY -l20000 ",treefile," > ",seqfile, sep=""))
x = read.dna(seqfile,format="sequential")
write.dna(x,file=seqfile,format="fasta")
system(paste("fasttree -nt -nosupport ",seqfile," > ", outfile,sep=""))

########################################
# estimate rate
########################################
t = read.tree(outfile)
t = write.tree(root(t,outgroup="outgroup",resolve=TRUE))

result$tree = t
rate = rateSampleEstimation(result, spname=paste("_",1:npop,sep=""))
save(rate,file=ratefile)
