#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
ratenumber = as.numeric(args[1])
murate = as.numeric(args[2])
nsim = as.numeric(args[3])

source("~/tranrate/simulation/tranLibrary.R")
library(phybase)
library(stringr)
total1 = 1000000
total2 = 1000000
nsample = c(100,200,300,400,500)
rate = c(0.002,0.004, 0.006, 0.008)
tranrate = rate[ratenumber]
print(tranrate)
print(murate)
print(nsim)

SIRresult = sir_2(alpha1 = 0.000, beta1 = 0.0000005, gamma1 = 0.05, alpha2 = 0.0, beta2 = 0.0000005, gamma2 = 0.05, S11_0 = total1-1, S12_0 = 0, I11_0 = 1, I12_0 = 0, R11_0 = 0, R12_0 = 0, S22_0 = total2-1, S21_0 = 0, I22_0 = 1, I21_0 = 0, R22_0 = 0, R21_0 = 0, times = seq(0, 200))
SIRresult = round(SIRresult)
SIRresult[,2] = SIRresult[,2]+total1-apply(SIRresult[,c(2,4,6)],1,sum)
SIRresult[,8] = SIRresult[,8]+total2-apply(SIRresult[,c(8,10,12)],1,sum)

#susceptibles in descending order and recovery in ascending order
input1 = data.frame(SIRresult$S11,SIRresult$I11,SIRresult$R11,SIRresult$S21,SIRresult$I21,SIRresult$R21)
colnames(input1) = c("S11","I11","R11","S21","I21","R21")
for(i in 2:dim(input1)[1]){
	if(input1$S11[i]>input1$S11[i-1]){
		input1$I11[i] = input1$I11[i] + (input1$S11[i] - input1$S11[i-1])
		input1$S11[i] = input1$S11[i-1]
	}
	if(input1$R11[i]<input1$R11[i-1]){
		input1$I11[i] = input1$I11[i] - (input1$R11[i-1] - input1$R11[i])
		input1$R11[i] = input1$R11[i-1]
	}
}

#corrections for population 2
input2 = data.frame(SIRresult$S22,SIRresult$I22,SIRresult$R22,SIRresult$S12,SIRresult$I12,SIRresult$R12)
colnames(input2) = c("S11","I11","R11","S21","I21","R21")
for(i in 2:dim(input2)[1]){
	if(input2$S11[i]>input2$S11[i-1]){
		input2$I11[i] = input2$I11[i] + (input2$S11[i] - input2$S11[i-1])
		input2$S11[i] = input2$S11[i-1]
	}
	if(input2$R11[i]<input2$R11[i-1]){
		input2$I11[i] = input2$I11[i] - (input2$R11[i-1] - input2$R11[i])
		input2$R11[i] = input2$R11[i-1]
	}
}

rate_est = matrix(0,100,length(nsample))

for(mmm in 1:length(nsample)){
	print(mmm)
	for(kkk in nsim:nsim){
		generatetree = 1
	        while(generatetree==1){
			transnet1 = transNet(input1, total1 = total1, total2=total2, travelprob_w=0.000001, infection_v = tranrate)$net
			transnet2 = transNet(input2, total1 = total2, total2 = total1, travelprob_w = 0.000001, infection_v=tranrate)$net	
			samplesize1 = samplesize2 = nsample[mmm]
			x1 = sum(transnet2[,4] == 1)
			x2 = sum(transnet1[,4] == 1)
			index_infection_1 = which(transnet1[1:total1,1]>0)
			index_infection_2 = which(transnet2[1:total2,1]>0)
			num_infection_1 = length(index_infection_1)
			num_infection_2 = length(index_infection_2)
			x_t1 = rbinom(1, samplesize1, x1/num_infection_1)
			x_t2 = rbinom(1, samplesize2, x2/num_infection_2)
			sample1 = c(sample(index_infection_1, samplesize1-x_t1), sample(which(transnet1[,4]==1),x_t2))
			sample2 = c(sample(index_infection_2, samplesize2-x_t2), sample(which(transnet2[,4]==1),x_t1))

			tree1 = ancTree(transnet1, sample_inf=sample1, murate=murate)
			tree2 = ancTree(transnet2, sample_inf=sample2, murate=murate)
			tree2 = str_replace_all(tree2,"_0","_2")
			tree2 = str_replace_all(tree2,"_1","_0")
			tree2 = str_replace_all(tree2,"_2","_1")
			tree2 = str_replace_all(tree2,"S","Q")
			
			finaltree = paste("(",str_replace_all(paste("(",tree1,",",tree2,"):0.2",sep=""),";",":0.1"),",","outgroup:0.1",");",sep="")
			tree_1 = read.tree(text=finaltree)
			if(sum(table(tree_1$tip.label)>1)==0 & length(tree_1[[4]])-1 == tree_1[[3]]){
				print("tree is good!")
				generatetree=0
			}
		}

		write(finaltree,paste("tree",ratenumber,"_",kkk,mmm,sep=""))
		system(paste("seq-gen -or -mHKY -l20000 tree",ratenumber,"_",kkk,mmm," > seq",ratenumber,"_",kkk,mmm, sep=""))
		x = read.dna(paste("seq",ratenumber,"_",kkk,mmm, sep=""),format="sequential")
		write.dna(x,file=paste("seq",ratenumber,"_",kkk,mmm, sep=""),format="fasta")
		system(paste("fasttree -nt -nosupport seq",ratenumber,"_",kkk,mmm," >output",ratenumber,"_",kkk,mmm,sep=""))

		t = read.tree(paste("output",ratenumber,"_",kkk,mmm,sep=""))
		t = write.tree(root(t,outgroup="outgroup",resolve=TRUE))

		gtree = t
		spname = c("_1","_0")
		tree = read.tree.nodes(gtree)
		gnames = tree$names
		nodematrix = tree$nodes
		root = dim(nodematrix)[1]

		w = findMajorClades(inode=root, nodematrix, taxaname=gnames, root=root, clades="")
		w = w[w!=""]
		print(w)
		m = 1:length(w)
		for(i in 1:length(w)){
                	m[i]=length(species.name(w[i]))
        	}
		w1 = w[which(m==max(m))]
		subsample_names = species.name(w1)
		if(length(grep("S",subsample_names))>length(grep("Q",subsample_names))){
			if(length(grep("Q",subsample_names))>0){
				subsample_names = subsample_names[-grep("Q",subsample_names)]
			}
			subsample = gsub("S","",subsample_names)
			s1 = subsample[grep("_0",subsample)]
			s1 = as.numeric(gsub('_[0-9]+','',s1))
			s2 = subsample[grep("_1",subsample)] 
			s2 = as.numeric(gsub('_[0-9]+','',s2))
			estimate1 = (length(s2)/samplesize2)*(num_infection_2/total2)/(sum(transnet1[s1,3]-transnet1[s1,1])/length(s1)*num_infection_1)
		}else{
			if(length(grep("S",subsample_names))>0){
				subsample_names = subsample_names[-grep("S",subsample_names)]
			}
			subsample = gsub("Q","",subsample_names)
                        s1 = subsample[grep("_1",subsample)]
                        s1 = as.numeric(gsub('_[0-9]+','',s1))
                        s2 = subsample[grep("_0",subsample)]
                        s2 = as.numeric(gsub('_[0-9]+','',s2))
                        estimate1 = (length(s2)/samplesize2)*(num_infection_2/total2)/(sum(transnet1[s1,3]-transnet1[s1,1])/length(s1)*num_infection_1)
		}
		#estimate1 = (x_t2/samplesize2)*(num_infection_2/total2)/(sum(transnet1[sample1[1:(samplesize1-x_t1)],3]-transnet1[sample1[1:(samplesize1-x_t1)],1])/(samplesize1-x_t1)*num_infection_1)
		#estimate2 =  (x_t1/samplesize1)*(num_infection_1/total1)/(sum(transnet2[sample2[1:(samplesize2-x_t2)],3]-transnet2[sample2[1:(samplesize2-x_t2)],1])/(samplesize2-x_t2)*num_infection_2)			
		rate_est[kkk,mmm] = estimate1
		print("rate_Est")
                print(rate_est[kkk,mmm])
	}
}
colnames(rate_est) = nsample
write.csv(rate_est,file=paste("rate_est_",tranrate,"_",nsim,".csv",sep=""),row.names=F)




