#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
ratenumber = as.numeric(args[1])

source("~/tranrate/simulation/tranLibrary.R")
library(phybase)
library(stringr)
total1 = 1000000
total2 = 1000000
nsample = c(100,200,400,600,800,1000)
rate = c(0.002,0.004, 0.006, 0.008)
nsim = 100
rate_est = matrix(0,nsim,length(rate))
colnames(rate_est) = rate

for(i in 1:length(rate)){
	print(i)
	for(k in 1:nsim){
		SIRresult = sir_2(alpha1 = 0.000, beta1 = 0.0000005, gamma1 = 0.05, alpha2 = 0.0, beta2 = 0.0000005, gamma2 = 0.05, S11_0 = total1-1, S12_0 = 0, I11_0 = 1, I12_0 = 0, R11_0 = 0, R12_0 = 0, S22_0 = total2-1, S21_0 = 0, I22_0 = 1, I21_0 = 0, R22_0 = 0, R21_0 = 0, times = seq(0, 200))
		SIRresult = round(SIRresult)
		SIRresult[,2] = SIRresult[,2]+total1-apply(SIRresult[,c(2,4,6)],1,sum)

		#susceptibles in descending order and recovery in ascending order
		input1 = data.frame(SIRresult$S11,SIRresult$I11,SIRresult$R11,SIRresult$S21,SIRresult$I21,SIRresult$R21)
		colnames(input1) = c("S11","I11","R11","S21","I21","R21")
		for(j in 2:dim(input1)[1]){
        		if(input1$S11[j]>input1$S11[j-1]){
                		input1$I11[j] = input1$I11[j] + (input1$S11[j] - input1$S11[j-1])
                		input1$S11[j] = input1$S11[j-1]
        		}
        		if(input1$R11[j]<input1$R11[j-1]){
                		input1$I11[j] = input1$I11[j] - (input1$R11[j-1] - input1$R11[j])
                		input1$R11[j] = input1$R11[j-1]
        		}
		}

		transnet = transNet(input1, total1 = total1, total2=total2, travelprob_w=0.000001, infection_v=rate[i])
		rate_est[k,i] = transnet$estimate
	}
}
write.csv(rate_est,file="rate_est_1000000.csv",row.names=F)



